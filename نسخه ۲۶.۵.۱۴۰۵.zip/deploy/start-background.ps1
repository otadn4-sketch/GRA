[CmdletBinding()]
param(
    [string]$HostAddress = "0.0.0.0",
    [int]$Port = 8000
)

$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$python = Join-Path $projectRoot ".venv\Scripts\python.exe"
$runDir = Join-Path $projectRoot "run"
$logDir = Join-Path $projectRoot "data\logs"
if (-not (Test-Path -LiteralPath $python)) { throw "Run deploy\install.ps1 first." }
foreach ($folder in @($runDir, $logDir)) {
    if (-not (Test-Path -LiteralPath $folder)) { New-Item -ItemType Directory -Path $folder | Out-Null }
}
$pidPath = Join-Path $runDir "garaye.pid"
if (Test-Path -LiteralPath $pidPath) {
    $oldPid = [int](Get-Content -LiteralPath $pidPath -Raw)
    if (Get-Process -Id $oldPid -ErrorAction SilentlyContinue) {
        throw "Garaye is already running with PID $oldPid."
    }
}
$arguments = @(
    "-m", "uvicorn", "app.main:app",
    "--host", $HostAddress,
    "--port", [string]$Port,
    "--proxy-headers"
)
$process = Start-Process -FilePath $python -ArgumentList $arguments `
    -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput (Join-Path $logDir "service.out.log") `
    -RedirectStandardError (Join-Path $logDir "service.err.log")
Set-Content -LiteralPath $pidPath -Value $process.Id -Encoding ASCII

$probeHost = if ($HostAddress -in @("0.0.0.0", "::", "[::]")) { "127.0.0.1" } else { $HostAddress }
$healthUri = "http://$($probeHost):$Port/health"
$health = $null
for ($attempt = 1; $attempt -le 20; $attempt++) {
    Start-Sleep -Milliseconds 750
    if ($process.HasExited) { break }
    try {
        $health = Invoke-RestMethod -Method Get -Uri $healthUri -TimeoutSec 2
        if ($health.ok) { break }
    }
    catch {
        $health = $null
    }
}

if (-not $health -or -not $health.ok) {
    if (-not $process.HasExited) {
        Stop-Process -Id $process.Id -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $pidPath) {
        Remove-Item -LiteralPath $pidPath -Force
    }
    $errorLog = Join-Path $logDir "service.err.log"
    $tail = if (Test-Path -LiteralPath $errorLog) {
        (Get-Content -LiteralPath $errorLog -Tail 40 -ErrorAction SilentlyContinue) -join [Environment]::NewLine
    } else {
        "service.err.log was not created."
    }
    throw "Garaye did not become healthy at $healthUri. Last service errors:`n$tail"
}

Write-Host "Garaye v$($health.version) is healthy with PID $($process.Id) on port $Port."
Write-Host "Open http://$($probeHost):$Port/login"
