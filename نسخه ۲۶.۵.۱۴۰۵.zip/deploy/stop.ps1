$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$pidPath = Join-Path $projectRoot "run\garaye.pid"
if (Test-Path -LiteralPath $pidPath) {
    $servicePid = [int](Get-Content -LiteralPath $pidPath -Raw)
    $process = Get-CimInstance Win32_Process -Filter "ProcessId=$servicePid" -ErrorAction SilentlyContinue
    if ($process) {
        $expectedPython = (Resolve-Path (Join-Path $projectRoot ".venv\Scripts\python.exe")).Path
        if (-not [string]::Equals($process.ExecutablePath, $expectedPython, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Recorded PID does not belong to the Garaye virtual environment. Stop cancelled."
        }
        Stop-Process -Id $servicePid
        Write-Host "Garaye service stopped."
    }
    Remove-Item -LiteralPath $pidPath -Force
}
else {
    Write-Host "Web service PID file not found."
}
& (Join-Path $PSScriptRoot "stop-crawler.ps1")
